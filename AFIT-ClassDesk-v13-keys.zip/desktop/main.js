const { app, BrowserWindow, Menu, dialog, shell } = require("electron");
const { fork, exec } = require("node:child_process");
const crypto = require("node:crypto");
const fs = require("node:fs");
const net = require("node:net");
const path = require("node:path");

let win = null, server = null, pgInstance = null, url = "", quitting = false;
if (!app.requestSingleInstanceLock()) app.quit();
app.on("second-instance", () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });

const data = () => app.getPath("userData");
const res = (...p) => app.isPackaged ? path.join(process.resourcesPath, ...p) : path.join(__dirname, "payload", ...p);

function loadEnv(file) {
  const env = {};
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    if (/^\s*#/.test(line)) continue;
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/); if (m) { const v = m[2].replace(/^"(.*)"$/, "$1"); if (v !== "") env[m[1]] = v; }
  }
  return env;
}
const freePort = () => new Promise((ok, bad) => { const s = net.createServer(); s.listen(0, "127.0.0.1", () => { const p = s.address().port; s.close(() => ok(p)); }); s.on("error", bad); });
const waitPort = (port, tries = 120) => new Promise((ok, bad) => { const t = (n) => { const c = net.connect(port, "127.0.0.1"); c.on("connect", () => { c.destroy(); ok(); }); c.on("error", () => { c.destroy(); n <= 0 ? bad(new Error("Server did not start")) : setTimeout(() => t(n - 1), 250); }); }; t(tries); });

const keysFile = () => path.join(data(), "keys", "API-KEYS.env");
function ensureConfig() {
  const file = keysFile();
  if (!fs.existsSync(file)) { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.copyFileSync(res("API-KEYS.env"), file); }
  return file;
}
function sessionSecret() {
  const f = path.join(data(), "secret.key");
  if (!fs.existsSync(f)) fs.writeFileSync(f, crypto.randomBytes(48).toString("hex"));
  return fs.readFileSync(f, "utf8").trim();
}

/* ---- Offline database: a real PostgreSQL running from this app, data kept on this PC ---- */
async function startDatabase() {
  const { default: EmbeddedPostgres } = await import("embedded-postgres");
  const { Client } = require("pg");
  const dir = path.join(data(), "pgdata"), port = await freePort(), pass = "classdesk-local";
  pgInstance = new EmbeddedPostgres({ databaseDir: dir, user: "classdesk", password: pass, port, persistent: true, onLog: () => {}, onError: () => {} });
  if (!fs.existsSync(path.join(dir, "PG_VERSION"))) await pgInstance.initialise();
  await pgInstance.start();
  const admin = new Client({ host: "127.0.0.1", port, user: "classdesk", password: pass, database: "postgres" });
  await admin.connect();
  const exists = await admin.query("SELECT 1 FROM pg_database WHERE datname='classdesk'");
  if (!exists.rowCount) await admin.query('CREATE DATABASE "classdesk"');
  await admin.end();
  const db = new Client({ host: "127.0.0.1", port, user: "classdesk", password: pass, database: "classdesk" });
  await db.connect();
  await db.query('CREATE TABLE IF NOT EXISTS "_desktop_migrations" (name text PRIMARY KEY, applied_at timestamptz DEFAULT now())');
  const done = new Set((await db.query('SELECT name FROM "_desktop_migrations"')).rows.map(r => r.name));
  const mdir = res("migrations");
  for (const name of fs.readdirSync(mdir).filter(n => fs.existsSync(path.join(mdir, n, "migration.sql"))).sort()) {
    if (done.has(name)) continue;
    await db.query("BEGIN");
    try { await db.query(fs.readFileSync(path.join(mdir, name, "migration.sql"), "utf8")); await db.query('INSERT INTO "_desktop_migrations"(name) VALUES ($1)', [name]); await db.query("COMMIT"); }
    catch (e) { await db.query("ROLLBACK"); throw new Error(`Database setup failed in ${name}: ${e.message}`); }
  }
  await db.end();
  return `postgresql://classdesk:${pass}@127.0.0.1:${port}/classdesk`;
}

async function start() {
  const cfg = ensureConfig(); const env = loadEnv(cfg);
  if (!env.ADMIN_PASSWORD && !env.ADMIN_PASSWORD_HASH) {
    await shell.openPath(cfg);
    await dialog.showMessageBox({ type: "info", title: "AFIT ClassDesk setup", message: "First-time setup", detail: "Your API keys file opened in Notepad.\n\nType your login password between the quotes after ADMIN_PASSWORD=. Add your MISTRAL_API_KEY (chat + voice listening) and, if you like, ELEVENLABS_API_KEY (Ava\'s voice). Save, then start ClassDesk again." });
    app.quit(); return;
  }
  const databaseUrl = await startDatabase();
  const port = await freePort();
  const dir = res("server");
  fs.mkdirSync(path.join(data(), "files"), { recursive: true });
  server = fork(path.join(dir, "server.js"), [], { cwd: dir, silent: true, env: { ...process.env, ...env, DATABASE_URL: databaseUrl, SESSION_SECRET: sessionSecret(), LOCAL_STORAGE_DIR: path.join(data(), "files"), ELECTRON_RUN_AS_NODE: "1", NODE_ENV: "production", PORT: String(port), HOSTNAME: "127.0.0.1" } });
  const logFile = path.join(data(), "server.log"); const log = fs.createWriteStream(logFile, { flags: "a" });
  server.stdout.pipe(log); server.stderr.pipe(log);
  server.on("exit", (code) => { if (!quitting && code) dialog.showErrorBox("ClassDesk stopped", `The local server exited (code ${code}).\nLog: ${logFile}`); });
  await waitPort(port);
  url = `http://127.0.0.1:${port}`;
  win = new BrowserWindow({ width: 1280, height: 820, minWidth: 420, title: "AFIT ClassDesk", icon: path.join(__dirname, "build", "icon.png"), backgroundColor: "#07111f", webPreferences: { contextIsolation: true, sandbox: true } });
  win.webContents.setWindowOpenHandler(({ url: u }) => { if (!u.startsWith(url)) { shell.openExternal(u); return { action: "deny" }; } return { action: "allow" }; });
  win.webContents.session.setPermissionRequestHandler((_wc, perm, cb) => cb(["media", "notifications"].includes(perm)));
  win.on("closed", () => { win = null; });
  await win.loadURL(`${url}/login`);
}

const openInEdge = () => { if (url) exec(`start msedge --app=${url}`, { shell: "cmd.exe" }, (e) => { if (e) shell.openExternal(url); }); };
app.whenReady().then(async () => {
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    { label: "ClassDesk", submenu: [
      { label: "Open in Edge window (voice listening)", click: openInEdge },
      { label: "Edit API keys", click: () => shell.openPath(keysFile()) },
      { label: "Open data folder (backup this!)", click: () => shell.openPath(data()) },
      { label: "Open server log", click: () => shell.openPath(path.join(data(), "server.log")) },
      { type: "separator" }, { role: "reload" }, { role: "quit" } ] },
    { label: "Edit", submenu: [{ role: "copy" }, { role: "paste" }, { role: "selectAll" }] }
  ]));
  try { await start(); } catch (e) { dialog.showErrorBox("ClassDesk failed to start", String((e && e.message) || e)); quitting = true; try { server?.kill(); await pgInstance?.stop(); } catch {} app.exit(1); }
});
app.on("before-quit", async (e) => {
  if (quitting) return; quitting = true;
  if (server || pgInstance) { e.preventDefault(); try { server?.kill(); } catch {} try { await pgInstance?.stop(); } catch {} app.exit(0); }
});
app.on("window-all-closed", () => app.quit());

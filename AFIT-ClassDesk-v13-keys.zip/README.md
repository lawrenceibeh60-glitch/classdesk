# AFIT ClassDesk

A private, single-administrator academic coordination workspace for an AFIT ND1 Electrical/Electronics Engineering Technology class representative (2026/2027). It is an independent tool, not an official AFIT portal.

## Features
- Class dashboard, searchable records, conflict-aware record sync and offline queues for academic records, announcements, document uploads and AI requests.
- Course catalogue, lecture sessions, assignment deadlines, aggregate attendance summaries and class concerns.
- Weekly timetable and academic calendar combining dated events, open assignment deadlines and scheduled lectures, with iCalendar export.
- Lecture document upload and searchable extraction for PDF, DOCX, PPTX, TXT, Markdown, PNG, JPG and WEBP. Scanned PDFs and images support English OCR.
- AI academic assistant and draft generation grounded in uploaded materials and recorded class facts.
- Announcement drafting, human approval, publication, archive, version history and audit events.
- Catch-up and weekly DOCX/PDF exports.
- Complete ZIP backup and explicit-confirmation restore, including original files when object storage is configured; JSON-only export is also available. Backups are unencrypted and must be stored securely.
- Private S3-compatible original-file storage and download when configured.

## Quick start

Requirements: Node.js 22, npm 10+, PostgreSQL.

```bash
cp .env.example .env
# Edit DATABASE_URL and SESSION_SECRET. Configure ADMIN_PASSWORD_HASH.
npm install --no-audit --no-fund
npx prisma migrate deploy
npm run dev
```

Generate a bcrypt hash:

```bash
node scripts/hash-password.mjs 'your-long-admin-password'
```

Copy the output into `ADMIN_PASSWORD_HASH`. Generate a secure `SESSION_SECRET` with a password manager or cryptographic random generator. Do not commit `.env`.

## Validate before deployment

```bash
npm run verify:source
npx prisma validate
npx prisma generate
npm run typecheck
npm run lint
npm run build
```

A GitHub Actions workflow runs these checks on pushes and pull requests. Do not deploy unless the workflow passes.

## Configuration notes
- `DATABASE_URL`, `SESSION_SECRET` and an administrator credential are required.
- `S3_*` variables are optional; without object storage, document text remains searchable but the original uploaded file is not retained.
- `CLAMAV_HOST` and `CLAMAV_PORT` enable ClamAV scanning; set `REQUIRE_MALWARE_SCAN=true` to reject uploads when no scanner is configured. Without a scanner, files are marked UNSCANNED, not CLEAN.
- `AI_*` variables are optional; AI features return a configuration error until an endpoint, key and model are configured.
- The app currently uses lexical retrieval, not vector embeddings. Scanned PDFs and images use server-side English OCR. OCR is CPU-intensive and can increase request duration.
- Offline queues cover class records, academic workflow entries, announcement drafts, document uploads and AI requests. AI requests are executed after reconnection; AI itself is not available offline. Announcement approval/publication requires a connection.

See [docs/V8-CHANGELOG.md](docs/V8-CHANGELOG.md) and [docs/V7-CHANGELOG.md](docs/V7-CHANGELOG.md), [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md), [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/ROADMAP.md](docs/ROADMAP.md).

## Windows desktop installer (.exe) - fully offline
Build on a Windows PC (Node 20.11+, internet needed only while building):
1. `npm install`
2. `npm run desktop:build` -> installer in `dist-desktop/AFIT ClassDesk Setup x.y.z.exe`
No database server or cloud account needed: the installed app runs its own PostgreSQL and keeps uploads on this PC (`%APPDATA%/AFIT ClassDesk`). First launch opens a settings file: set ADMIN_PASSWORD, save, start again.
Back up by copying the data folder (menu: ClassDesk > Open data folder) or use the in-app backup tools.

## API keys (one file)
All keys live in `keys/API-KEYS.env` (desktop: ClassDesk menu > Edit API keys). Chat uses Mistral (`MISTRAL_API_KEY`); the same key powers Ava listening (Voxtral). `ELEVENLABS_API_KEY` gives Ava a natural British voice.
## (old) AI setup
ClassDesk talks to any OpenAI-compatible endpoint. Set `AI_BASE_URL` (ends before `/chat/completions`), `AI_API_KEY` and `AI_MODEL` in the settings file (desktop: ClassDesk menu > Edit settings). Restart the app after saving.
## Ava voice
Tap the mic (or Alt+A), then say "Ava, ...". Chrome/Edge/Safari needed for listening; speaking works offline.

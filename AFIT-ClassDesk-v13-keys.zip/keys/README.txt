Put all API keys in API-KEYS.env (this folder). Desktop app: ClassDesk menu > "Edit API keys".
Do not commit or share API-KEYS.env.

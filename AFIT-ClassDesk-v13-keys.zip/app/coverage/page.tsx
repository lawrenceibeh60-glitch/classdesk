import { redirect } from "next/navigation";
import { isAuthenticated } from "@/lib/auth";
import CoverageView from "@/components/coverage-view";
export default async function Page() { if (!(await isAuthenticated())) redirect("/login"); return <CoverageView />; }
